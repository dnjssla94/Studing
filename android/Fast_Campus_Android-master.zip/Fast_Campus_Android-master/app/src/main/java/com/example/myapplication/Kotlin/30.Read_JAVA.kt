package com.example.myapplication.Kotlin







fun main(args: Array<String>) {

    /* This reads the input provided by user
         * using keyboard
         */
    /* This reads the input provided by user
         * using keyboard
         */
//    val scan = Scanner(System.`in`)
//    print("Enter first number: ")
//
//    val num1: Int = scan.nextInt()
//
//    print("Enter second number: ")
//    val num2: Int = scan.nextInt()
//
//    scan.close()
//
//    val product = num1 * num2
//
//    println("Output: $product")

}