#사용자 함수
# def  functionName():
#     print("functionCall")
#     return True


# c = 10
# def add(a,b):
#     global c
#     c= a + b
#     return a+b

# d=add(12,543)

#인자에 기본값을 주는게 완성도를 높이는 방법.
# def get_input_user(msg, casting = int):
#     '''사용자에게  msg를 출력하고 casting 형태를 확인하여 입력된 값을 리턴합니다.

#     Args:
#         msg(str): input  시 출력할 문구
#         castring (class) : 사용자에게 입력 받는 값의 자료형

#     returns:
#         user (castirg-value) : 사용자에게 입력받은 값
#     '''
#     while True:
#         try:
#             user = casting(input(msg))
#             return user
#         except:
#             continue

# user = get_input_user("사용자 이름을 입력하시오: ", str)
# age = get_input_user("사용자 나이를 입력하시오.")

# print(user)
# print(age)

# def test1(num):
#     num += 10
#     print(num)

#list, dictionary, set은 함수의 인자일 시  call by reference가 된다.

#------------------------------------------------------------------

# def save_winner(*args):# 인자값이 정해지지않게됨 튜플 값으로 넘어감
#     print(args)

# save_winner("djfjro" , "eage" , "yut")

# def save_winner2(**kwargs):#키워드 argument. 딕셔너리 형태로 넘어감 
#     print(kwargs)
#     if kwargs.get("name1"):
#         print(kwargs["name1"])

# save_winner2(name1 = "으어어", name2 = "흐어어")


#----------------------------------------------------

# def hi():
#     print("Hello")

# WOW = hi
# WOW()

# def add(a,b):
#     return a + b

# def cal(func,a,b):
#     print("결과 {}".format(func(a,b)))

# cal(add, 3,5)

#--------------------------------------------------

def outer_functino(func):
    def inner_function(*args, **kwargs): #어떤 인자를 넣어도 다 받을 수 있음
        print("함수명 : {}".format(func.__name__))
        print("args : {}".format(args))
        print("kwargs : {}".format(kwargs))
        result = func(*args, **kwargs)
        print("result : {}".format(result))
        return result
    return inner_function

def add(a,b):
    return a + b

f = outer_functino(add)
f(1345,2465)