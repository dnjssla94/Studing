for i in range(0,3):
    print(i)