class FishCakeMaker:
    def __init__(self):#생성자
        pass

fish = FishCakeMaker()
