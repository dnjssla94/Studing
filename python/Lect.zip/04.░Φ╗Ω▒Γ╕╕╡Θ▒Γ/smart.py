

operator = ['+','-','*','/','=']
user_input = str(input("계산식을 입력하시오: "))

string_list = []
lop = 0     #last_operator_pose

if user_input[-1] not in operator:
    user_input += "="

for i, s in enumerate(user_input):
    if s in operator:
        if user_input[lop:i].strip() != "": #마지막 연산자부터 i번째까지가 공백이 아니어아함
            string_list.append(user_input[lop:i])
            string_list.append(s)
            lop = i + 1

string_list = string_list[:-1]
print(string_list)

pos = 0
