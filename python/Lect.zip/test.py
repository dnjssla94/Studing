list = [1,2,3,4]

print(list[0:-3])